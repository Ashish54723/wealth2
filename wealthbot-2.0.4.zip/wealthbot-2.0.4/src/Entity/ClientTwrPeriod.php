<?php


namespace App\Entity;

/**
 * Class ClientTwrPeriod
 * @package App\Entity
 */
class ClientTwrPeriod
{
}
