<?php


namespace App\Entity;

/**
 * Class PortfolioModel
 * @package App\Entity
 */
class PortfolioModel
{
}
