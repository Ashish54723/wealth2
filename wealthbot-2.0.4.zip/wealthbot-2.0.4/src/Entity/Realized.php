<?php


namespace App\Entity;

/**
 * Class Realized
 * @package App\Entity
 */
class Realized
{
    const STATUS_MATCH = 'status_match';
}
