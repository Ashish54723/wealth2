<?php


namespace App\Entity;

/**
 * Class ModelAssumption
 * @package App\Entity
 */
class ModelAssumption
{
}
