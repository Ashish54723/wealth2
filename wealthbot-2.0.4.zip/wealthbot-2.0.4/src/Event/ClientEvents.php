<?php
/**
 * Created by JetBrains PhpStorm.
 * User: amalyuhin
 * Date: 19.07.13
 * Time: 17:42
 * To change this template use File | Settings | File Templates.
 */

namespace App\Event;

final class ClientEvents
{
    const CLIENT_WORKFLOW = 'client.workflow';
}
