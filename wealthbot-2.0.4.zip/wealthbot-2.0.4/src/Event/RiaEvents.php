<?php
/**
 * Created by JetBrains PhpStorm.
 * User: maksim
 * Date: 21.05.13
 * Time: 2:08
 * To change this template use File | Settings | File Templates.
 */

namespace App\Event;

final class RiaEvents
{
    const RIA_FLASH_MESSAGE = 'ria.flash_message';
}
