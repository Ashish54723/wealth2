<?php

namespace App\Event;

final class AdminEvents
{
    const USER_HISTORY = 'user.history';
}
