var App = new Backbone.Marionette.Application();

App.addRegions({
    mainRegion: 'mainApp'
});


App.Var = {};
App.Const = {};

App.Var.straightProcessing = '';

App.start();