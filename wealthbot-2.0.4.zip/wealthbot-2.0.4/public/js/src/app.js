var Util  = {};
var App   = new Backbone.Marionette.Application();
App.Var   = {};
App.Const = {};
App.addRegions({ mainRegion: 'mainApp' });
App.start();